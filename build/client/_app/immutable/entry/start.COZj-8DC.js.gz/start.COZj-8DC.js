import{a as t}from"../chunks/entry.kvkKl4KD.js";export{t as start};
