import{a as t}from"../chunks/entry.D8jNUrBP.js";export{t as start};
