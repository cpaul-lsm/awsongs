import{a as t}from"../chunks/entry.B8lklS_z.js";export{t as start};
