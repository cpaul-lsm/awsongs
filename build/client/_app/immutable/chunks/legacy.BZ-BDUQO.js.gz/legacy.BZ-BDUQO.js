import{_ as a}from"./runtime.DAUSjKms.js";a();
