const index = 1;
let component_cache;
const component = async () => component_cache ??= (await import('./error.svelte-CdxACq6o.js')).default;
const imports = ["_app/immutable/nodes/1.Hr3UKVCv.js","_app/immutable/chunks/disclose-version.Bg9kRutz.js","_app/immutable/chunks/legacy.BZ-BDUQO.js","_app/immutable/chunks/runtime.DAUSjKms.js","_app/immutable/chunks/render.DzTF58AG.js","_app/immutable/chunks/misc.0zgdeyB0.js","_app/immutable/chunks/template.DXirXkmM.js","_app/immutable/chunks/lifecycle.B5bOo5d6.js","_app/immutable/chunks/entry.D8jNUrBP.js","_app/immutable/chunks/index-client.BUs9hEbT.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=1-CrTDIaDw.js.map
