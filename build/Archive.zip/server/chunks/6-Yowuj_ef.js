const index = 6;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DFw4XSLb.js')).default;
const imports = ["_app/immutable/nodes/6.1vxrzUel.js","_app/immutable/chunks/disclose-version.Bg9kRutz.js","_app/immutable/chunks/legacy.BZ-BDUQO.js","_app/immutable/chunks/runtime.DAUSjKms.js","_app/immutable/chunks/template.DXirXkmM.js","_app/immutable/chunks/attributes.C_nMD1v0.js","_app/immutable/chunks/misc.0zgdeyB0.js","_app/immutable/chunks/lifecycle.B5bOo5d6.js","_app/immutable/chunks/index-client.BUs9hEbT.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=6-Yowuj_ef.js.map
