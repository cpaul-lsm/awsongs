const index = 0;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-Dq84hGZR.js')).default;
const imports = ["_app/immutable/nodes/0.Cp32AOtu.js","_app/immutable/chunks/disclose-version.Bg9kRutz.js","_app/immutable/chunks/legacy.BZ-BDUQO.js","_app/immutable/chunks/runtime.DAUSjKms.js","_app/immutable/chunks/template.DXirXkmM.js"];
const stylesheets = ["_app/immutable/assets/0.k9tLmqyM.css"];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=0-CMuefb92.js.map
