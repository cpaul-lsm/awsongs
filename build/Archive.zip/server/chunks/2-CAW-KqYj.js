const index = 2;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DnW4W2Qs.js')).default;
const imports = ["_app/immutable/nodes/2.BuZpp3_Q.js","_app/immutable/chunks/disclose-version.Bg9kRutz.js","_app/immutable/chunks/legacy.BZ-BDUQO.js","_app/immutable/chunks/runtime.DAUSjKms.js","_app/immutable/chunks/lifecycle.B5bOo5d6.js","_app/immutable/chunks/index-client.BUs9hEbT.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=2-CAW-KqYj.js.map
