import { d as slot } from './index-RKtuUzxt.js';

function _layout($$payload, $$props) {
  $$payload.out += `<section class="app-layout pad-st"><main class="max-w-st flex flex-col justify-center"><!---->`;
  slot($$payload, $$props, "default", {});
  $$payload.out += `<!----></main></section>`;
}

export { _layout as default };
//# sourceMappingURL=_layout.svelte-Dq84hGZR.js.map
