const index = 3;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-D3G_r7QM.js')).default;
const imports = ["_app/immutable/nodes/3.BUN7U7RY.js","_app/immutable/chunks/disclose-version.Bg9kRutz.js","_app/immutable/chunks/runtime.DAUSjKms.js","_app/immutable/chunks/render.DzTF58AG.js","_app/immutable/chunks/misc.0zgdeyB0.js","_app/immutable/chunks/template.DXirXkmM.js","_app/immutable/chunks/if.Yz_L7sOg.js","_app/immutable/chunks/attributes.C_nMD1v0.js","_app/immutable/chunks/input.CPAq-8ic.js","_app/immutable/chunks/proxy.CoxkSrJ3.js","_app/immutable/chunks/entry.D8jNUrBP.js","_app/immutable/chunks/index-client.BUs9hEbT.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=3-CCXYdD-4.js.map
