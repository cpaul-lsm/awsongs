const index = 5;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DsoydsZw.js')).default;
const imports = ["_app/immutable/nodes/5.DXRbr_ip.js","_app/immutable/chunks/disclose-version.Bg9kRutz.js","_app/immutable/chunks/runtime.DAUSjKms.js","_app/immutable/chunks/render.DzTF58AG.js","_app/immutable/chunks/misc.0zgdeyB0.js","_app/immutable/chunks/template.DXirXkmM.js","_app/immutable/chunks/if.Yz_L7sOg.js","_app/immutable/chunks/requests.Ce_-iLRG.js","_app/immutable/chunks/proxy.CoxkSrJ3.js","_app/immutable/chunks/index-client.BUs9hEbT.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=5-B-eqePt-.js.map
