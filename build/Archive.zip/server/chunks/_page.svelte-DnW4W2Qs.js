import { c as pop, p as push } from './index-RKtuUzxt.js';

function _page($$payload, $$props) {
  push();
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-DnW4W2Qs.js.map
