const index = 4;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DQCZjnnZ.js')).default;
const imports = ["_app/immutable/nodes/4.1E9DYjAD.js","_app/immutable/chunks/disclose-version.Bg9kRutz.js","_app/immutable/chunks/runtime.DAUSjKms.js","_app/immutable/chunks/render.DzTF58AG.js","_app/immutable/chunks/misc.0zgdeyB0.js","_app/immutable/chunks/template.DXirXkmM.js","_app/immutable/chunks/if.Yz_L7sOg.js","_app/immutable/chunks/requests.Ce_-iLRG.js","_app/immutable/chunks/attributes.C_nMD1v0.js","_app/immutable/chunks/input.CPAq-8ic.js","_app/immutable/chunks/proxy.CoxkSrJ3.js","_app/immutable/chunks/index-client.BUs9hEbT.js","_app/immutable/chunks/entry.D8jNUrBP.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=4-lLLXzCwg.js.map
