const requests = [
  {
    id: 996031,
    date: "2025-01-16",
    time: "23:51",
    song: "All of Me (John Legend)",
    firstname: "Goofy",
    comments: "Pluto is my pal"
  },
  {
    id: 779036,
    date: "2025-01-16",
    time: "00:00",
    song: "American Beauty (Drew Holcomb)",
    firstname: "Mickey Mouse",
    comments: "I love Minnie"
  },
  {
    id: 612802,
    date: "2025-01-16",
    time: "00:20",
    song: "All I Want Is You (U2)",
    firstname: "Kermit",
    comments: "I love Ms Piggy"
  },
  {
    id: 668736,
    date: "2025-01-16",
    time: "01:03",
    song: "Dancing in the Sky (Dani and Lizzy)",
    firstname: "Tiny Tim",
    comments: "God bless everyone"
  },
  {
    id: 309077,
    date: "2025-01-16",
    time: "22:26",
    song: "",
    firstname: "Crawford",
    comments: "Welcome"
  }
];

export { requests as r };
//# sourceMappingURL=requests-DcQxKDSs.js.map
